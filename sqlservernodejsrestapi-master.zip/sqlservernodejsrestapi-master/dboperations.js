var config = require('./dbconfig');
const sql = require('mssql');


async function getUsers() {
    try {
        let pool = await sql.connect(config);
        let products = await pool.request().query("SELECT * from trackCulprit.CulpritInfo");
        return products.recordsets;
    }
    catch (error) {
        console.error("An error occurred:", error);
    }
}

async function getUser(Id) {
    try {
        let pool = await sql.connect(config);
        let product = await pool.request()
            .input('input_parameter', sql.Int, Id)
            .query("SELECT * from trackCulprit.CulpritInfo where Id = @input_parameter");
        return product.recordsets;

    }
    catch (error) {
        console.error("An error occurred:", error);
    }
}


async function addUser(order) {

    try {
        let pool = await sql.connect(config);
        let insertProduct = await pool.request()
            .input('Name', sql.NVarChar, order.Name)
            .input('IP', sql.NVarChar, order.IP)
            .input('Latitude', sql.NVarChar, order.Latitude)
            .input('Longitude', sql.NVarChar, order.Longitude)
            .input('URL', sql.NVarChar, order.URL)
            .execute('trackCulprit.InsertCulpritData');
        return insertProduct.recordsets;
    }
    catch (err) {
        console.error("An error occurred:", err);
    }

}

module.exports = {
    getUsers: getUsers,
    getUser : getUser,
    addUser: addUser
}