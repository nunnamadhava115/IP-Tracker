// const express = require('express');
// const bodyParser = require('body-parser');
// const sql = require('mssql'); // Add this line
// const app = express();
// var config = require('./dbconfig');
// const cors = require('cors');
// // Configure the connection to your Azure SQL Database

// const dboperations = require('./dboperations');
// var router = express.Router();

// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());
// app.use(cors());
// app.use('/api', router);
// app.use(express.static(__dirname));

// // Use bodyParser middleware for handling form data

// app.get('/', (req, res) => {
//     res.send(`<html lang="en">
//     <head>
//         <meta charset="UTF-8">
//         <meta name="viewport" content="width=device-width, initial-scale=1.0">
//         <link rel="stylesheet" href="styles.css">
//     </head>
//     <body>
//         <div class="login-container">
//         <img style="width:80px;height:80px;background-color: #8d448b;border-radius: 70px;" src="./images/people-icon.svg"></img>
//             <h1 style="color:#8d448b; font-size: 20px;">Have an account?</h1>
//             <div class="form-group">
//                 <label for="username"  style="display: none;">Usernames</label>
//                 <input type="text" id="username" style="margin-bottom: 1rem;width: 60%;height: 48px;background: rgba(0, 0, 0, 0.05);border-radius: 5px;" placeholder="Usernames">
//             </div>
//             <div class="form-group">
//                 <label for="password"  style="display: none;">Password</label>
//                 <input type="password" id="password" style="margin-bottom: 1rem;width: 60%;height: 48px;background: rgba(0, 0, 0, 0.05);border-radius: 5px;" placeholder="Password">
//             </div>
//             <button class="button" style="width: 100px;height: 42px;" onclick="login()">Login</button> 
//         </div>
//         <div class="generate-link-container" style="display: none;">
//             <header>
//                 <h1>Latest Breaking News</h1>
//             </header>
//             <nav>
//                 <a href="#" onclick="showDashboard()">Dashboard</a>
//                 <a href="#" onclick="showReports()">Reports</a>
//                 <a href="dummy.html">Logout</a>
//             </nav>
//             </div>
//             <div class="generate-link-container1" style="display: none;padding: 50px;">
//             <label for="heading">Content</label>
//             <select style="margin-bottom: 1rem;" id="contentDropdown" required="">
//                 <option value="" selected>Select Content Type</option>
//                 <option>
//                 PreDefined
//                 </option>
//                 <option>
//                     Redirecting
//                     </option>
//                 <option>
//                 Customized
//                 </option>
//                 </select>
//         </div>
//         <div class="generate-link-container2" style="display: none;">
//             <h2 style="color:#8d448b">Generate Link</h2>
//             <div class="form-group">
//                 <label for="content" class="required">Content:</label>
//                 <input type="text" id="predefinedContent" style="margin-bottom: 1rem;"placeholder="Enter Content" required=""><br/>
//                 <label for="name" class="required">Name:</label>
//                 <input type="text" id="predefinedName" style="margin-bottom: 1rem;"placeholder="Enter Name" required="">
//             </div>
//             <div class="form-group">
//                 <label for="heading" class="required">Heading:</label>
//                 <select style="margin-bottom: 1rem;" id="predefinedHeading" required="">
//                     <option value="" selected>Select Heading</option>
//                     <option>
//                     భలే కేటుగాళ్ళు...పాతిక లక్షలతో పరారీ
//                     </option>
//                     <option>
//                     ఫ్లాష్&zwnj;...ఫ్లాష్&zwnj;.... తెలుగు రాష్ట్రాల్లో తీవ్ర కలకలం
//                     అధికార యంత్రాంగం అత్యవసర సమావేశం
//                     </option>
//                     <option>
//                     ఫేస్&zwnj;బుక్&zwnj; కేటుగాడు భలే చిక్కాడు...
//                     </option>
//                     <option>
//                     పోలీసుల చేతికి ‘సైబర్&zwnj; మంత్ర’
//                     </option>
//                     <option>
//                     ఫ్లాష్&zwnj;...ఫ్లాష్&zwnj;...
//                     వందల పాములు...వేల నాగమణులు
//                     </option>
//                     <option>
//                     పోలీసుల పేరుతోనే టోకరా...
//                     </option>
//                     <option>
//                     ఈ యాప్&zwnj;తో హ్యాకింగ్&zwnj; చాలా సుళువు
//                     </option>
//                     <option>
//                     నకిలీ ఇన్&zwnj;స్టాగ్రామ్&zwnj; అకౌంట్&zwnj;తో వేధింపులు...
//                     </option>
//                     <option>
//                     చీర సొగసుల్లో అనసూయ ఒంపుసొంపులు
//                     </option>
//                     <option>
//                     యువతి అదృశ్యం...పోలీసుల దర్యాప్తు
//                     </option>
//                     <option>
//                     ఛాటింగ్&zwnj;...ఛీటింగ్&zwnj;...
//                     </option>
//                     <option>
//                     అబ్బాయిపై బెంగతో మంచం పట్టిన తల్లి
//                     </option>
//                     <option>
//                     Amazon gift card scam: Now there is a fake profile of Collector.
//                     </option>
//                     <option>
//                     Andhra Couple Dies by Suicide Over Harassment from Loan App Owners, Dials Cousin Minutes Before Consuming Poison
//                     </option>
//                     <option>
//                     పెళ్లి పేరిట మహిళా టెకీకి టోకరా! కోటి రూపాయలతో పరారైన ఘరానా మోసగాడు! తెలుగురాష్ట్రాల్లో గాలింపు
//                     </option>
//                     <option>
//                     చస్తే చావండి..కానీ లోన్ కట్టండి”.. యాప్ వేధింపులకు మరో యువకుడు మృతి
//                     </option>
//                     <option>
//                     కారుతో ఢీకొట్టి మహిళ దారుణ హత్య.. సీసీ కెమెరాల్లో రికార్డైన షాకింగ్&zwnj; దృశ్యాలు
//                     </option>
//                     <option>
//                     వందల్లో చోరీలు.. కొట్టేసిన డబ్బు, నగలు దాచేది వల్లకాటిలో.. ఎలాగో తెలిస్తే షాక్..
//                     </option>
//                     <option>
//                     తీగ లాగితే డొంక: అతని చేతిలో దొంగల ముఠాలు
//                     </option>
//                     <option>
//                     వాట్సప్&zwnj; వేధింపులపై కేసు నమోదు
//                     </option>
//                     <option>
//                     అమ్మాయి అదృశ్యం...మంచం పట్టిన తల్లి
//                     </option>
//                     <option>
//                     दो वाहन गंभीर रूप से घायल तीन
//                     </option>
//                     <option>
//                     ప్రోటాన్&zwnj; మెయిల్&zwnj;తో వేధింపులపై కేసు నమోదు
//                     </option>
//                     <option>
//                     రోడ్డుపై నిలువు దోపిడీ...పోలీసుల అదుపులో దొంగలు
//                     </option>
//                     <option>
//                     మాచర్ల ఎమ్మెల్యేను హతమార్చడమే లక్ష్యంగా ఘర్షణలు…
//                     </option>
//                     <option>
//                     ICAI CA Foundation December 2022 Mock Test 2 series begins today, details here
//                     </option>
//                     <option>
//                     మాచర్ల ఘటనలో ఊహించని షాక్
//                     </option>
//                     <option>
//                     మాచర్ల మాస్టర్&zwnj;మైండ్&zwnj; అతడే
//                     </option>
//                     <option>
//                     హైద్రాబాద్&zwnj;లో...మాచర్ల పోలీసుల గాలింపు
//                     </option>
//                     <option>
//                     మాచర్ల ఘటన...హైద్రాబాద్&zwnj;లో ముమ్మర గాలింపు
//                     </option>
//                     <option>
//                     इंडिया में घूमने की 50 खूबसूरत जगह
//                     </option>
//                     <option>
//                     Swiped Off Man's PhonePe Wallet By Delhi Scammers.&nbsp;Here's&nbsp;How
//                     </option>
//                     <option>
//                     అతి తక్కువ పెట్టుబడితో...కళ్ళు చెదిరే లాభాలు...
//                     </option>
//                     <option>
//                     అంగళ్ళు ఘటనలో ‘భారీ కుట్రకోణం’ లీకైన ఆడియో కాల్&zwnj;లో మొత్తం ఫ్లాన్&zwnj; వివరాలు నాలుగు రోజుల ముందుగానే పక్కా ప్రణాళిక
//                     </option>
//                     <option>
//                     ఉద్యోగాల పేరుతో కొత్త తరహా మోసం
//                     </option>
//                     <option>
//                     Transaction successful
//                     </option>
//                     <option>
//                     వాస్తవ్&zwnj; టీవీ కార్యాలయానికి మంత్రుల రాక నేడు
//                     </option>
//                     <option>
//                     గురజాలలో షాకింగ్ వీడియో వైరల్
//                     </option>
//                     <option>
//                     వైసీపీ కార్యకర్త దారుణ హత్య, వెలుగులోకి కీలక కాల్ రికార్డు
//                     </option>
//                     </select>
//             </div>
//             <button class="button" onclick="generateLink(document.getElementById('predefinedHeading').value,document.getElementById('predefinedContent').value,document.getElementById('predefinedName').value,'predefined')">Generate Now</button> 
//             <p id="result"></p>
//             <button onclick="copyText('result')">Copy URL</button>
//         </div>
//         <div class="generate-link-container3" style="display: none;">
//             <h2 style="color:#8d448b">Generate Link</h2>
//             <div class="form-group">
//                 <label for="content" class="required">Content:</label>
//                 <input type="text" id="customizedContent" style="margin-bottom: 1rem;"placeholder="Enter Content" required=""><br/>
//                 <label for="name" class="required">Name:</label>
//                 <input type="text" id="customizedName" style="margin-bottom: 1rem;"placeholder="Enter Name" required="">
//             </div>
//             <div class="form-group">
//                 <label for="heading" class="required">Heading:</label>
//                 <input type="text" id="customizedHeading" style="margin-bottom: 1rem;"placeholder="Enter Heading" required="">
//             </div>
//             <button class="button" onclick="generateLink(document.getElementById('customizedHeading').value,document.getElementById('customizedContent').value,document.getElementById('customizedName').value,'customized')">Generate Now</button> 
//             <p id="customizedResult"></p> 
//             <button onclick="copyText('customizedResult')">Copy URL</button>
//         </div>
//         <div class="fetchReports" style="display: none;">
//         <h2 style="color:#8d448b">Fetch Reports</h2>
//         <div class="form-group">
//             <label for="culpritName" class="required">Culprit Name:</label>
//             <input type="text" id="culpritName" style="margin-bottom: 1rem;"placeholder="Enter Name" required=""><br/>
//             <button class="button" onclick="fetchReports()">Fetch Reports</button> 
//         </div>
// </div>
    
//     </body>
//     <script src="loginform.js"></script> 

//     </html>
    
//  `);
//   });

// app.post('/insertContent', async (req, res) => {

//     const { url, heading, bodyContent,id,name } = req.body;
//     try {
//         console.log("data in insertcontent function"+bodyContent);
//         await sql.connect(config);

//         const query = `
//             INSERT INTO trackCulprit.Content (Url, Heading, BodyContent,Id,Name)
//             VALUES (@url, @heading, @bodyContent,@id,@name)
//         `;

//         await new sql.Request()
//             .input('url', sql.NVarChar, url)
//             .input('heading', sql.NVarChar, heading)
//             .input('bodyContent', sql.NVarChar, bodyContent)
//             .input('id',sql.NVarChar,id)
//             .input('name',sql.NVarChar,name)
//             .query(query);

//         res.send('Data inserted successfully');
//     } catch (err) {
//         console.error('Error:', err);
//         res.status(500).send('Error inserting data');
//     } finally {
//         sql.close();
//     }
// });


// app.get('/articles/:url', async (req, res) => {
//     const url = "https://track-culprit-dev.azurewebsites.net"+req.originalUrl;
//     try {
//         await sql.connect(config);
//         const query = 'SELECT BodyContent, Heading FROM trackCulprit.Content WHERE Url = @url';
//         const result = await new sql.Request()
//             .input('url', sql.NVarChar, url)
//             .query(query);
 
//         const { BodyContent, Heading } = result.recordset[0];
//         const html = `
//             <html lang="te">
//             <head>
//                 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
//                 <meta name="google" content="notranslate" />
//                 <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">
//                 <link href="https://getbootstrap.com/docs/4.0/examples/offcanvas/offcanvas.css" rel="stylesheet">
//             </head>
//             <body>
//                 <nav class="navbar navbar-expand-md fixed-top navbar-dark bg-dark">
//                     <a class="navbar-brand" href="#" style="font-size: 32px;">తాజా వార్తలు</a>
//                     <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
//                         <span class="navbar-toggler-icon"></span>
//                     </button>
//                 </nav>
//                 <main role="main" class="container">
//                     <br>
//                     <div class="starter-template">
//                         <h1>${Heading}</h1>
//                         <hr>
//                         <p class="lead" style="padding: 10px; margin-top: 10px;">${BodyContent}</p>
//                     </div>
//                 </main>
//                 <script>
//                 window.addEventListener('load', () => {
//                     // Check if the location and IP have already been fetched
//                     if (localStorage.getItem('hasFetchedLocation') !== 'true') {
//                         if (navigator.geolocation) {
//                             fetchDetails();
//                             localStorage.setItem('hasFetchedLocation', 'true');
//                         } else {
//                             console.error("Geolocation is not supported by this browser.");
//                         }
//                     } else {
//                         fetchDetails();
//                     }
//                 });
                             
//                 function insertDbData(ip,latitude,longitude) {
//                 // Define the API endpoint URL
//                 const apiUrl = 'https://track-culprit-dev.azurewebsites.net/api/users'; // Replace with your API URL
//                 const data = {
//                     "Name": "TestUser",
//                     "IP": ip,
//                     "Latitude": latitude,
//                     "Longitude": longitude,
//                     "URL": "URL"
//                 }
//                 // Make a GET request using the fetch API
//                 fetch(apiUrl, {
//                         method: 'POST',
//                         headers: {
//                             'Content-Type': 'application/json'
//                         },
//                         body: JSON.stringify(data)
//                     })
//                   .then(response => {
//                     if (!response.ok) {
//                       throw new Error('Network response was not ok');
//                     }
//                     return response.json(); // Parse the response as JSON
//                   })
//                   .then(data => {
//                     // Use the data from the API response
                
//                   })
//                   .catch(error => {
//                     console.error('There was a problem with the fetch operation:', error);
//                   });
//                 }
                
//                 async function fetchDetails() {
//                     try {
//                         const position = await new Promise((resolve, reject) => {
//                             navigator.geolocation.getCurrentPosition(resolve, reject);
//                         });
                
//                         const latitude = position.coords.latitude;
//                         const longitude = position.coords.longitude;
//                         const ipAddress = await fetchIpAddress(); // Use "await" here
//                         insertDbData(ipAddress, latitude, longitude);
//                     } catch (error) {
//                         const ipAddress = await fetchIpAddress(); // Use "await" here
//                         insertDbData(ipAddress, 'NA', 'NA');
//                         console.log("Error getting location:", error);
//                     }
//                 }

//                 async function fetchIpAddress() {
//                     const response = await fetch('https://api64.ipify.org?format=json');
//                     const data = await response.json();
//                     return data.ip;
//                 }
                
//                 </script>
//             </body>
//             </html>
//         `;
 
//         res.send(html);
//     } catch (err) {
//         console.error('Error:', err);
//     } finally {
//         sql.close();
//     }
//  });

//  app.post('/logout', (req, res) => {
//     // Clear the session or perform any other necessary logout operations
//     req.session.destroy((err) => {
//         if (err) {
//             console.error('Error destroying session:', err);
//             res.status(500).send('Logout failed');
//         } else {
//             //res.clearCookie('session'); // Clear the session cookie if needed
//             res.sendStatus(200); // Send a success response
//         }
//     });
// });


// // Start the server



// router.use((request,response,next)=>{
//     next();
//  })
 
//  router.route('/users').get((request,response)=>{
 
//      dboperations.getUsers().then(result => {
//         response.json(result[0]);
//      })
 
//  })
 
//  router.route('/users/:id').get((request,response)=>{
 
//      dboperations.getUser(request.params.id).then(result => {
//         response.json(result[0]);
//      })
 
//  })
 
//  router.route('/users').post((request,response)=>{
 
//      let order = {...request.body}
 
//      dboperations.addUser(order).then(result => {
//         response.status(201).json(result);
//      })
 
//  })
 
// var port = process.env.PORT || 5000;
// app.listen(port, () => {
//     console.log(`Server is running on port ${port}`);
// });
