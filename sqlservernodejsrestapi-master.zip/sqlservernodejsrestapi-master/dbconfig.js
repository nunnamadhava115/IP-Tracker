
const config = {
    user: 'Adminusername', // better stored in an app setting such as process.env.DB_USER
    password: 'Password@123', // better stored in an app setting such as process.env.DB_PASSWORD
    server: 'inventory-managment-server.database.windows.net', // better stored in an app setting such as process.env.DB_SERVER
    port: 1433, // optional, defaults to 1433, better stored in an app setting such as process.env.DB_PORT
    database: 'inventory-management-database', // better stored in an app setting such as process.env.DB_NAME
    
    authentication: {
        type: 'default'
    },
    options:{
        trustedconnection: true,
        enableArithAbort : true, 
        instancename :'SQLEXPRESS'
    }
}

module.exports = config; 