function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Check login credentials here and determine user role (admin/user)
    if (username === "admin" && password === "adminpass") {
        showGenerateLinkPage();
    } else if (username === "user" && password === "userpass") {
        alert("User login successful");
    } else {
        alert("Invalid credentials");
    }
}

function showGenerateLinkPage() {
    const loginContainer = document.querySelector(".login-container");
    const generateLinkContainer = document.querySelector(".generate-link-container");

    if (loginContainer && generateLinkContainer) {
        loginContainer.style.display = "none";
        generateLinkContainer.style.display = "block";
    }
}

function showDashboard() {
    const loginContainer = document.querySelector(".login-container");
    const showDashboard = document.querySelector(".generate-link-container1");

    if (loginContainer && showDashboard) {
        loginContainer.style.display = "none";
        showDashboard.style.display = "block";

        // Get the select element
        const selectElement = document.getElementById('predefinedOptions');

        // Get the div container
        const dropdownElement = document.getElementById("contentDropdown");
        const generateLinkContainer = document.querySelector('.generate-link-container2');
        const generateLinkContainer3 = document.querySelector('.generate-link-container3');
        // Add event listener for change event
        dropdownElement.addEventListener('change', function () {
            // Get the selected value from the dropdown
            const dropdownValue = dropdownElement.value;

            // Check if the selected option has a value
            if (dropdownValue === 'PreDefined') {
                console.log("display: " + dropdownValue);
                // Show the generate link container
                generateLinkContainer.style.display = "block";
                generateLinkContainer3.style.display = "none";
                document.getElementById('predefinedContent').value = "";
                document.getElementById('predefinedName').value = "";
                document.getElementById('predefinedHeading').selectedIndex = 0;
                document.getElementById("result").textContent = "";

            } else if (dropdownValue === 'Customized') {
                console.log("display none: " + dropdownValue);
                // Hide the generate link container if no option is selected
                generateLinkContainer3.style.display = "block";
                generateLinkContainer.style.display = "none";
                document.getElementById('customizedContent').value = "";
                document.getElementById('customizedName').value = "";
                document.getElementById('customizedHeading').value = "";
                document.getElementById("customizedresult").textContent = "";
            }
        });


        //});



    }
}

function showReports() {
    const loginContainer = document.querySelector(".login-container");
    const showDashboard = document.querySelector(".generate-link-container");

    if (loginContainer && showDashboard) {
        loginContainer.style.display = "none";
        showDashboard.style.display = "block";
        const reportsPage = document.querySelector('.fetchReports');
        reportsPage.style.display = "block";
    }
}

function generateLink(heading, bodyContent, name, type) {
    //const heading = document.getElementById("heading").value;
    //const bodyContent = document.getElementById("content").value;
    //const name = document.getElementById("name").value;
    console.log(heading, bodyContent, name, type)
    if (!heading || !bodyContent || !name) {
        alert("Please fill in all the mandatory fields");
        return;
    }
    const randomIdentifier = Math.floor(Math.random() * 1000000);
    const baseUrl = "https://track-culprit-dev.azurewebsites.net/articles/";
    const uniqueUrl = baseUrl + randomIdentifier;
    const id = generateId();
    const data = {
        url: uniqueUrl,
        heading: heading,
        bodyContent: bodyContent,
        id: id,
        name: name
    };

    fetch('https://track-culprit-dev.azurewebsites.net/insertContent', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
        .then(response => {
            if (response.ok) {
                return response.text(); // Data inserted successfully
            } else {
                throw new Error('Error inserting data');
            }
        })
        .then(data => {
        })
        .catch(error => {
            console.error("An error occurred:", error); // Handle errors
        });
    if (type == "predefined") {
        document.getElementById("result").textContent = uniqueUrl;
    }
    else {
        document.getElementById("customizedResult").textContent = uniqueUrl;
    }

}

function generateId() {
    return Math.random().toString(36).substring(2, 7);
}

function copyText(idName) {
console.log(idName);
    /* Select text area by id*/
    var Text = document.getElementById(idName);

    /* Select the text inside text area. */


    /* Copy selected text into clipboard */
    navigator.clipboard.writeText(Text.textContent);


}

function logoutUser() {
    // Send an AJAX request to the server to log out the user
    fetch('https://track-culprit-dev.azurewebsites.net/logout', {
        method: 'POST' // Send cookies along with the request if needed
    })
        .then(response => {
            if (response.ok) {
                // Redirect the user to the login page or perform any other action after successful logout
                // window.location.href = '/dashboard-trial';

                // Redirect to the login page
            } else {
                console.error('Logout failed');
            }
        })
        .catch(error => {
            console.error('Error during logout:', error);
        });
}




